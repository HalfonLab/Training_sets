#!/usr/bin/env python
import os
import sys

# Hasiba Asma Aug 6th 2018
#This script is to convert the training set crms file to the format that is used to input in IMOGENE (coord.bed) but before using this file as an input you need to convert these back to dm5 using flybase converter.


greppedDmelCrms=sys.argv[1]
tsetName= sys.argv[2]
i=1
newFileName= tsetName+'_CoordImogFormat.bed'
with open(greppedDmelCrms,'r') as tsetFile, open(newFileName,'w') as cord:
	for line in tsetFile:
		row=line.split(':')
		chrName=row[2]
		coords=row[3].split('-')
		start=coords[0]
		end=coords[1].strip('\n')
		cord.write(chrName+'\t'+start+'\t'+end+'\t'+'crm'+str(i)+'\n')
		i=i+1
		
